package nor.zero.bluetoothtest;


import android.os.Handler;

public class BluetoothChatService {

    public BluetoothChatService(BlueToothChat activity, Handler handler){}



}
